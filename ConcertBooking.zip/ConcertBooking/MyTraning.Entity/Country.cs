﻿namespace MyTraning.Entity
{
    public class Country
    {
        public int Id { get; set; }
        public string Name { get; set; } = "Default Country";
        //Navigation Property
        public ICollection<State> States { get; set; } = new HashSet<State>();

    }
}