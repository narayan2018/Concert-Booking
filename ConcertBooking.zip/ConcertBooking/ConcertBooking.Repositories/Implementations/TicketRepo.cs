﻿using ConcertBooking.Entities;
using Microsoft.EntityFrameworkCore;

namespace ConcertBooking.Repositories
{
    public class TicketRepo : ITicketRepo
    {
        private readonly ApplicationDbContext _context;

        public TicketRepo(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<int>> GetBookedTickets(int id)
        {
            var bookedTickets = await _context.Tickets.Include(x=>x.Booking).Where(t => t.Booking.ConcertId == id && t.IsBooked)
                .Select(t => t.SeatNumber).ToListAsync();
            return bookedTickets;
        }

        public async Task<IEnumerable<Booking>> GetBookings(string userId)
        {
            var bookings = await _context.Bookings.Where(x => x.UserId == userId).Include(y => y.Tickets).Include(x => x.Concert).ToListAsync();

            return bookings;
        }
    }
}
