﻿using ConcertBooking.Entities;
using ConcertBooking.Infrastructure;
using Microsoft.AspNetCore.Identity;

namespace ConcertBooking.Repositories
{
    public class DbInitial : IDbInitial
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public DbInitial(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public  Task Seed()
        {
           if(!_roleManager.RoleExistsAsync(GlobalConfiguration.Role_Admin).GetAwaiter().GetResult())
            {
                _roleManager.CreateAsync(new IdentityRole(GlobalConfiguration.Role_Admin)).GetAwaiter().GetResult();

                var user = new ApplicationUser()
                {
                    Email="admin1@gmail.com",
                    UserName= "admin1@gmail.com"
                };

                _userManager.CreateAsync(user, "Admin@2024").GetAwaiter().GetResult();
                _userManager.AddToRoleAsync(user, GlobalConfiguration.Role_Admin).GetAwaiter().GetResult();
            }
            return Task.CompletedTask;
        }
    }
}
