﻿namespace MyTrainingWeb.ViewModels
{
    public class CountriesVM
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
