﻿namespace MyTrainingWeb.ViewModels
{
    public class CountriesCreateVM
    {
        public string? Name { get; set; }
    }
}
