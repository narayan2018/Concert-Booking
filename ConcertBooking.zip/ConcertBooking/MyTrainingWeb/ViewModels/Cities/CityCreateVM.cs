﻿namespace MyTrainingWeb.ViewModels
{
    public class CityCreateVM
    {
        public string Name { get; set; } 
        public int StateId { get; set; }
    }
}
