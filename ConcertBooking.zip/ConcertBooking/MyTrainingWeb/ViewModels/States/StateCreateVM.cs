﻿using System.ComponentModel.DataAnnotations;

namespace MyTrainingWeb.ViewModels
{
    public class StateCreateVM
    {
        public string Name { get; set; }

        [Display(Name = "Country Name")]
        public int CountryId { get; set; }

    }
}
