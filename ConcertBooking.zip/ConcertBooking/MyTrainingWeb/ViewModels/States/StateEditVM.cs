﻿using System.ComponentModel.DataAnnotations;

namespace MyTrainingWeb.ViewModels
{
    public class StateEditVM
    {
        public int Id { get; set; }
        public string Name { get; set; }

        [Display(Name = "Country Name")]
        public int CountryId { get; set; }
    }
}
