﻿using Microsoft.AspNetCore.Mvc;
using MyTraning.Repository;

namespace MyTrainingWeb.ViewComponents
{
    public class CountStateViewComponent : ViewComponent
    {
        private readonly IStateRepo _stateRepo;

        public CountStateViewComponent(IStateRepo stateRepo)
        {
            _stateRepo = stateRepo;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var states =await _stateRepo.GetAll();

            int stateCount= states.Count();
            return View(stateCount);
        }
    }
}
