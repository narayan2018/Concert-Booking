﻿using Microsoft.AspNetCore.Mvc;
using MyTraning.Repository;

namespace MyTrainingWeb.ViewComponents
{
    public class CountCountryViewComponent:ViewComponent
    {
        private readonly ICountryRepo _countryRepo;

        public CountCountryViewComponent(ICountryRepo countryRepo)
        {
            _countryRepo = countryRepo;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var country = await _countryRepo.GetAll();
            int count = country.Count();
            return View(count);
        }
    }
}
