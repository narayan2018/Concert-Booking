﻿using Microsoft.AspNetCore.Mvc;
using MyTraning.Repository;

namespace MyTrainingWeb.ViewComponents
{
    public class CountCityViewComponent : ViewComponent
    {
        private readonly ICityRepo _cityRepo;

        public CountCityViewComponent(ICityRepo cityRepo)
        {
            _cityRepo = cityRepo;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var city = await _cityRepo.GetAll();
            int count = city.Count();
            return View(count);
        }
    }
}
