﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MyTrainingWeb.ViewModels;
using MyTraning.Entity;
using MyTraning.Repository;

namespace MyTrainingWeb.Controllers
{
    public class CitiesController : Controller
    {
        private readonly ICityRepo _cityRepo;
        private readonly IStateRepo _stateRepo;

        public CitiesController(ICityRepo cityRepo, IStateRepo stateRepo)
        {
            _cityRepo = cityRepo;
            _stateRepo = stateRepo; 
        }

        public async Task<IActionResult> Index()
        {
           var cityList=await _cityRepo.GetAll();

            var vm = new List<CityVM>();
            foreach (var item in cityList)
            {
                vm.Add( new CityVM() { Id=item.Id, 
                    Name=item.Name,
                    StateName=item.State?.Name,
                    CountryName=item.State?.Country.Name
                });
            }
            return View(vm);
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var stateList =await _stateRepo.GetAll();
            ViewBag.StateList = new SelectList(stateList, "Id", "Name");

            var vm = new CityCreateVM();
            return View(vm);
        }
        [HttpPost]
        public async Task<IActionResult> Create(CityCreateVM vm)
        {
            var city = new City()
            {
                Name = vm.Name,
                StateId = vm.StateId,
            };
           await _cityRepo.Save(city);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var stateList =await _stateRepo.GetAll();
            ViewBag.StateList = new SelectList(stateList, "Id", "Name");

            var city=await _cityRepo.GetById(id);

            var vm = new CityEditVM()
            {
                StateId = city.StateId,
                Id=city.Id,
                Name = city.Name,
            };
            return View(vm);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(CityEditVM vm)
        {
            var city = new City()
            {
                Id = vm.Id,
                Name = vm.Name,
                StateId = vm.StateId,
            };
            await _cityRepo.Edit(city);
            return RedirectToAction("Index");
        }
    }
}
