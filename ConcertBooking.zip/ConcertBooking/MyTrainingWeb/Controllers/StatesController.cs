﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MyTrainingWeb.ViewModels;
using MyTraning.Entity;
using MyTraning.Repository;

namespace MyTrainingWeb.Controllers
{
    public class StatesController : Controller
    {
        private readonly IStateRepo _stateRepo;
        private readonly ICountryRepo _countryRepo;

        public StatesController(IStateRepo stateRepo, ICountryRepo countryRepo)
        {
            _stateRepo = stateRepo;
            _countryRepo = countryRepo;
        }

        public async Task<IActionResult> Index()
        {
            var states =await _stateRepo.GetAll();

            var vm = new List<StateVM>();

            foreach (var item in states)
            {
                vm.Add(new StateVM()
                {
                    Id= item.Id,
                    Name= item.Name,
                    CountryName= item.Country.Name,
                });
            }
            return View(vm);
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var countryLis=await _countryRepo.GetAll();
            ViewBag.CountryList = new SelectList(countryLis, "Id", "Name");
            var vm = new StateCreateVM();

            return View(vm);
        }

        [HttpPost]
        public async Task<IActionResult> Create(StateCreateVM vm)
        {
            var state = new State()
            {
                Name = vm.Name,
                CountryId = vm.CountryId
            };
           await _stateRepo.Save(state);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var entity =await _stateRepo.GetById(id);
            var countryLis =await _countryRepo.GetAll();
            ViewBag.CountryList = new SelectList(countryLis, "Id", "Name");

            var vm = new StateEditVM()
            {
                Id = id,
                Name = entity.Name,
                CountryId = entity.CountryId
            };
            return View(vm);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(StateEditVM vm)
        {
            var state = new State()
            {
                CountryId = vm.CountryId,
                Name = vm.Name,
                Id = vm.Id
            };
           await _stateRepo.Edit(state);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var entity =await _stateRepo.GetById(id);
            StateVM vm = new StateVM()
            {
                Id = entity.Id,
                Name = entity.Name,
               // CountryName = entity.Country.Name
            };
            return View(vm);
        }
        [HttpPost]
        public async Task<IActionResult> Delete(StateVM vm)
        {
            var state = new State()
            {
                Id=vm.Id,
                Name=vm.Name
            };
           await _stateRepo.Delete(state);
            return RedirectToAction("Index");
        }
    }
}
