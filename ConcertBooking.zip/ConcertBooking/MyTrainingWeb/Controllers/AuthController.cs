﻿using Microsoft.AspNetCore.Mvc;
using MyTrainingWeb.ViewModels;
using MyTraning.Entity;
using MyTraning.Repository;

namespace MyTrainingWeb.Controllers
{
    public class AuthController : Controller
    {
        private IUserInfoRepo _userInfoRepo;

        public AuthController(IUserInfoRepo userInfoRepo)
        {
            _userInfoRepo = userInfoRepo;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(UserInfoVM vm)
        {
            var user = new UserInfo()
            {
                UserName = vm.UserName,
                Password = vm.Password,
            };

            await _userInfoRepo.RegisterUser(user);

            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpGet]
        public IActionResult LogOut()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        [HttpPost]
        public async Task<IActionResult> Login(UserInfoVM vm)
        {
            var user = new UserInfo()
            {
                UserName = vm.UserName,
                Password = vm.Password,
            };

            var userInfo = await _userInfoRepo.GetUserInfo(user.UserName,user.Password);

            HttpContext.Session.SetInt32("UserId", userInfo.UserId);
            HttpContext.Session.SetString("UserName", userInfo.UserName);
            return RedirectToAction("Index","Countries");
        }
    }
}
