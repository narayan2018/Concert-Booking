﻿using Microsoft.AspNetCore.Mvc;
using MyTrainingWeb.ViewModels;
using MyTraning.Entity;
using MyTraning.Repository;

namespace MyTrainingWeb.Controllers
{
    public class CountriesController : Controller
    {
        private readonly ICountryRepo _countryRepo;

        public CountriesController(ICountryRepo countryRepo)
        {
            _countryRepo = countryRepo;
        }

        public async Task<IActionResult> Index()
        {

            if (HttpContext.Session.GetInt32("UserId") != null)
            {
                var dataList = await _countryRepo.GetAll();

                List<CountriesVM> vm = new List<CountriesVM>();

                foreach (var item in dataList)
                {
                    vm.Add(new CountriesVM() { Id = item.Id, Name = item.Name });
                }
                return View(vm);
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }
           
        }

        [HttpGet]
        public IActionResult Create()
        {
            var country = new CountriesCreateVM();
            return View(country);
        }

        [HttpPost]
        public async Task<IActionResult> Create(CountriesCreateVM vm)
        {
            var country = new Country()
            {
                Name=vm.Name
            };
           await  _countryRepo.Save(country);
           return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var entity=await _countryRepo.GetById(id);

            var vm = new CountriesVM()
            {
                Id = entity.Id,
                Name = entity.Name
            };
            return View(vm);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(CountriesVM vm)
        {
            var country = new Country()
            {
                Id = vm.Id,
                Name = vm.Name
            };
           await _countryRepo.Edit(country);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var entity =await _countryRepo.GetById(id);

            var vm = new CountriesVM()
            {
                Id= entity.Id,
                Name=entity.Name
            };
            return View(vm);
        }
        [HttpPost]
        public async Task<IActionResult> Delete(CountriesVM vm)
        {
            var country = new Country()
            {
                Id = vm.Id,
                Name = vm.Name
            };
           await _countryRepo.Delete(country);
            return RedirectToAction("Index");
        }
    }
}
