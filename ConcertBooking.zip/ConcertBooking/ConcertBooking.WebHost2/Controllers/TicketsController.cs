﻿using ConcertBooking.Repositories;
using ConcertBooking.WebHost2.ViewModels;
using ConcertBooking.WebHost2.ViewModels.Tickets;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ConcertBooking.WebHost2.Controllers
{
    public class TicketsController:Controller
    {
        private readonly ITicketRepo _ticketRepo;

        public TicketsController(ITicketRepo ticketRepo)
        {
            _ticketRepo = ticketRepo;
        }

        [Authorize]
        public async Task<IActionResult> MyTickets()
        {
            var claimIdentity = (ClaimsIdentity)(User.Identity);
            var claims = claimIdentity.FindFirst(ClaimTypes.NameIdentifier);
            var userId = claims.Value;
            var bookings = await _ticketRepo.GetBookings(userId);

            var vm = new List<BookingViewModel>();
            foreach (var item in bookings)
            {
                vm.Add(new BookingViewModel()
                {
                    BookingId = item.BookingId,
                    BookingDate = item.BookingDate,
                    ConcertName = item.Concert.Name,
                    Tickets = item.Tickets.Select(t => new TicketsViewModel()
                    {
                        SeatNumber = t.SeatNumber
                    }).ToList(),
                });
            }

            return View(vm);
        }
    }
}
