﻿namespace ConcertBooking.WebHost2.ViewModels
{
    public class CreateArtistViewModel
    {
        public string Name { get; set; }
        public string Bio { get; set; }
        public IFormFile ImageUrl { get; set; }
    }
}
