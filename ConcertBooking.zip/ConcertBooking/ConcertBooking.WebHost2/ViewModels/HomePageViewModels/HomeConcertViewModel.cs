﻿namespace ConcertBooking.WebHost2.ViewModels
{
    public class HomeConcertViewModel
    {
        public int ConcertId { get; set; }
        public string ConcertName { get; set; }
        public string ArtistName { get; set; }
        public string ConcertImage { get; set; }
        public string Description { get; set; }
    }
}
