﻿namespace ConcertBooking.WebHost2.ViewModels
{
    public class DashboadViewModel
    {
        public string UserName { get; set; }
        public string ConcertName { get; set; }
        public string SeatNumber { get; set; }
    }
}
