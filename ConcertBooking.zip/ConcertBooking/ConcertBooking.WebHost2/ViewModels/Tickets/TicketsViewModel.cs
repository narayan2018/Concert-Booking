﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConcertBooking.WebHost2.ViewModels
{
    public class TicketsViewModel
    {
        public int SeatNumber { get; set; }

    }
}
