﻿namespace WebAppsUI.Models
{
    public class People
    {
        public int Id { get; set; }
        public string Name { get; set; } = "Name1";
        public string City { get; set; } = "City1";
    }
}
