﻿using Microsoft.AspNetCore.Mvc;
using WebAppsUI.Data;
using WebAppsUI.Models;

namespace WebAppsUI.Controllers
{
    public class PeopleController : Controller
    {

        private readonly ApplicationDBContext _dbContext;

        public PeopleController(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IActionResult Index()
        {
            var people=_dbContext.Peoples.ToList();
            return View(people);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();

        }

        [HttpPost]
        public IActionResult Create(People people)
        {
            _dbContext.Peoples.Add(people);
            _dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var people = _dbContext.Peoples.FirstOrDefault(x => x.Id == id);
            return View(people);

        }

        [HttpPost]
        public IActionResult Edit(People people)
        {
            _dbContext.Peoples.Update(people);
            _dbContext.SaveChanges();
            return RedirectToAction("Index");
            
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var people = _dbContext.Peoples.FirstOrDefault(x => x.Id == id);
            return View(people);

        }

        [HttpPost]
        public IActionResult Delete(People people)
        {
            _dbContext.Peoples.Remove(people);
            _dbContext.SaveChanges();
            return RedirectToAction("Index");

        }
    }
}
