﻿using Microsoft.EntityFrameworkCore;
using MyTraning.Entity;

namespace MyTraning.Repository
{
    public class StateRepo : IStateRepo
    {
        private readonly ApplicationDBContext _dbContext;

        public StateRepo(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task Save(State state)
        {
            await _dbContext.States.AddAsync(state);
            await _dbContext.SaveChangesAsync();
        }
        public async Task Delete(State entity)
        {
            _dbContext.States.Remove(entity);
           await _dbContext.SaveChangesAsync();
        }

        public async Task<State> Edit(State entity)
        {
            _dbContext.States.Update(entity);
             await _dbContext.SaveChangesAsync();

            return entity;
        }

        public async Task<IEnumerable<State>> GetAll()
        {
           return await _dbContext.States.Include(x=>x.Country).ToListAsync();
        }

        public async Task<State> GetById(int id)
        {
            var entity=await _dbContext.States.FindAsync(id);
            return entity;
        }
    }
}
