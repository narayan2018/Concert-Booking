﻿using Microsoft.EntityFrameworkCore;
using MyTraning.Entity;

namespace MyTraning.Repository
{
    public class CountryRepo : ICountryRepo
    {
        private readonly ApplicationDBContext _dbContext;

        public CountryRepo(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task Save(Country entity)
        {
           await _dbContext.Countries.AddAsync(entity);
          await  _dbContext.SaveChangesAsync();
        }
        public async Task Delete(Country country)
        {
            _dbContext.Countries.Remove(country);
           await _dbContext.SaveChangesAsync();
        }

        public async Task<Country> Edit(Country country)
        {
            _dbContext.Countries.Update(country);
           await _dbContext.SaveChangesAsync();
            return country;
        }

        public async Task<IEnumerable<Country>> GetAll()
        {
            return await _dbContext.Countries.ToListAsync();
        }

        public async Task<Country> GetById(int id)
        {
            var entity =await _dbContext.Countries.FindAsync(id);
            return entity;
        }
    }
}
