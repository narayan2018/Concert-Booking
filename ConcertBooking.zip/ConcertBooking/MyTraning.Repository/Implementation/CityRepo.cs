﻿using Microsoft.EntityFrameworkCore;
using MyTraning.Entity;

namespace MyTraning.Repository
{
    public class CityRepo : ICityRepo
    {

        private readonly ApplicationDBContext _dbContext;

        public CityRepo(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public  async Task Save(City entity)
        {
            _dbContext.Cities.Add(entity);
           await _dbContext.SaveChangesAsync();
        }
        public async Task Delete(City entity)
        {
            _dbContext.Cities.Remove(entity);
           await _dbContext.SaveChangesAsync();
        }

        public async Task<City> Edit(City entity)
        {
            _dbContext.Cities.Update(entity);
             await _dbContext.SaveChangesAsync();
            return entity;
        }

        public async Task<IEnumerable<City>> GetAll()
        {
            var entity =await _dbContext.Cities.Include(x=>x.State).ThenInclude(x=>x.Country).ToListAsync();
            return  entity;
        }

        public async Task<City> GetById(int id)
        {
            var entity =await _dbContext.Cities.FindAsync(id);
            return entity;
        }
    }
}
