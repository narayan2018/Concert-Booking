﻿using Microsoft.EntityFrameworkCore;
using MyTraning.Entity;

namespace MyTraning.Repository
{
    public class UserInfoRepo : IUserInfoRepo
    {
        private readonly ApplicationDBContext _context;

        public UserInfoRepo(ApplicationDBContext context)
        {
            _context = context;
        }

        public async Task<UserInfo> GetUserInfo(string userName, string password)
        {
           var user= await _context.UserInfos.FirstOrDefaultAsync(x=>x.UserName.ToLower()==userName.ToLower() && x.Password.ToLower() ==password.ToLower());

            return user;
        }

        public async Task RegisterUser(UserInfo user)
        {
            if(!Exist(user.UserName))
            {
                await _context.UserInfos.AddAsync(user);
                await _context.SaveChangesAsync();
            } 
        }


        private bool Exist(string userName)
        {
            return _context.UserInfos.Any(x=>x.UserName.ToLower() == userName.ToLower());
        }
    }
}
