﻿using MyTraning.Entity;

namespace MyTraning.Repository
{
    public interface IUserInfoRepo
    {
        Task RegisterUser(UserInfo user);

        Task<UserInfo> GetUserInfo(string userName, string password);

    }
}
