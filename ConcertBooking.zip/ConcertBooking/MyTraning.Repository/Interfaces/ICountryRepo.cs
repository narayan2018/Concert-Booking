﻿using MyTraning.Entity;

namespace MyTraning.Repository
{
    public interface ICountryRepo
    {

        Task<IEnumerable<Country>> GetAll();

        Task<Country> GetById(int id);

        Task Delete(Country entity);

        Task<Country> Edit(Country entity);
        Task Save(Country entity);
    }
}
