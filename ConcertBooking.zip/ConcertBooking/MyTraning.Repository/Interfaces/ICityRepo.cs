﻿using MyTraning.Entity;
namespace MyTraning.Repository
{
    public interface ICityRepo
    {
        Task<IEnumerable<City>> GetAll();

        Task<City> GetById(int id);

        Task Delete(City entity);

        Task<City> Edit(City entity);

        Task  Save(City entity);
    }
}
