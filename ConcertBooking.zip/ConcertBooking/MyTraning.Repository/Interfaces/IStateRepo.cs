﻿
using MyTraning.Entity;
namespace MyTraning.Repository
{
    public interface IStateRepo
    {
        Task<IEnumerable<State>> GetAll();

        Task<State> GetById(int id);

        Task Delete(State entity);

        Task<State> Edit(State entity);

        Task Save(State entity);
    }
}
