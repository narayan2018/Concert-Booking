﻿

using Microsoft.EntityFrameworkCore;
using MyTraning.Entity;

namespace MyTraning.Repository
{
    public class ApplicationDBContext : DbContext
    {

        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options)
        {

        }
        public DbSet<Country> Countries { get; set; }
        public DbSet<State> States { get; set; }
        public DbSet<City> Cities { get; set; }

        public DbSet<UserInfo> UserInfos { get; set; }
    }
}
