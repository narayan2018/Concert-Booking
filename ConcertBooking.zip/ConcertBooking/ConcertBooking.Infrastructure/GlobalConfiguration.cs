﻿namespace ConcertBooking.Infrastructure
{
    public class GlobalConfiguration
    {
        public const string Role_Admin = "Admin";
        public const string Role_User = "User";
    }
}